#pragma once
#include <math.h>
#include <stdint.h>
namespace edge_logistic_regression {
static constexpr int INPUT_SIZE = 36;
static constexpr int CLASS_COUNT = 3;
static const float WEIGHTS[108] = {
    -1.077099562e+00f, -3.647357702e+00f, 1.160923004e+00f, -1.533160806e+00f, -3.823371887e+00f, -1.389199972e+00f, -7.500887513e-01f, -2.879659653e+00f,
    4.837122858e-01f, -1.211772323e+00f, -3.307311296e+00f, -9.499807954e-01f, 2.282876253e+00f, 1.574822307e+00f, 5.316308737e-01f, 4.760522366e+00f,
    2.483373404e+00f, 3.323473930e-01f, 3.474531323e-02f, -8.846392483e-02f, 8.415636420e-02f, -9.399997443e-02f, -1.497601569e-01f, -5.021253973e-02f,
    -2.141472884e-02f, -8.443984389e-02f, 9.140967578e-02f, -6.993739307e-02f, -1.529277563e-01f, -4.383144155e-02f, 3.333519399e-01f, -5.601663589e-01f,
    3.463525772e-01f, -1.739416271e-01f, -5.244019032e-01f, -2.156592607e-01f, -4.184436798e-02f, 1.974586487e+00f, -2.395513058e-01f, 8.823357821e-01f,
    1.843198419e+00f, 6.464794278e-01f, -3.014825843e-02f, 5.190932751e-02f, 2.454964072e-01f, 5.070487857e-01f, 1.596197844e+00f, 1.843867153e-01f,
    -8.271592259e-01f, 2.370519876e+00f, 5.208287388e-02f, -3.248457909e+00f, -1.094164133e+00f, -6.564519405e-01f, -6.900329608e-03f, -3.045252338e-02f,
    -6.507112086e-02f, 7.560824603e-02f, 3.250187438e-04f, 3.960784525e-02f, 2.557131927e-03f, 4.083579779e-02f, -3.211261332e-02f, 4.847255722e-02f,
    -1.360610425e-01f, 2.223847806e-02f, -3.808776438e-01f, 2.932149470e-01f, -2.226198278e-02f, 1.652758867e-01f, 2.870962620e-01f, 6.554247439e-02f,
    1.118943930e+00f, 1.672771215e+00f, -9.213717580e-01f, 6.508250833e-01f, 1.980173588e+00f, 7.427205443e-01f, 7.802370191e-01f, 2.827750444e+00f,
    -7.292087078e-01f, 7.047234774e-01f, 1.711113453e+00f, 7.655941248e-01f, -1.455716968e+00f, -3.945342064e+00f, -5.837137103e-01f, -1.512064576e+00f,
    -1.389209151e+00f, 3.241045177e-01f, -2.784498408e-02f, 1.189164519e-01f, -1.908524521e-02f, 1.839172468e-02f, 1.494351327e-01f, 1.060469542e-02f,
    1.885759830e-02f, 4.360404611e-02f, -5.929706246e-02f, 2.146483958e-02f, 2.889887989e-01f, 2.159296535e-02f, 4.752572253e-02f, 2.669514120e-01f,
    -3.240906000e-01f, 8.665742353e-03f, 2.373056561e-01f, 1.501168013e-01f
};
static const float BIAS[3] = {
    -1.216957169e+02f, 6.691255188e+01f, 5.478316879e+01f
};

inline int predict(const float* x, float* probabilities = nullptr) {
    float scores[CLASS_COUNT];
    int best_class = 0;
    for (int c = 0; c < CLASS_COUNT; ++c) {
        float value = BIAS[c];
        for (int i = 0; i < INPUT_SIZE; ++i) {
            value += x[i] * WEIGHTS[c * INPUT_SIZE + i];
        }
        scores[c] = value;
        if (scores[c] > scores[best_class]) best_class = c;
    }
    if (probabilities != nullptr) {
        float maximum = scores[0];
        for (int c = 1; c < CLASS_COUNT; ++c) {
            if (scores[c] > maximum) maximum = scores[c];
        }
        float total = 0.0f;
        for (int c = 0; c < CLASS_COUNT; ++c) {
            probabilities[c] = expf(scores[c] - maximum);
            total += probabilities[c];
        }
        for (int c = 0; c < CLASS_COUNT; ++c) probabilities[c] /= total;
    }
    return best_class;
}
}  // namespace edge_logistic_regression
