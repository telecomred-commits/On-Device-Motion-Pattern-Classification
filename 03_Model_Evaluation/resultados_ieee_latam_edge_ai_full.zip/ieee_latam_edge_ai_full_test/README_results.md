# IEEE Latin America Transactions — Edge AI comparison

## Run

- Input: `dataset_features_q1(1).csv`
- SHA-256: `64a3a219770e66adb49b2a61f043d613a9a5f0cdda280065f2ea55e5d0556432`
- Mode: `full`
- Windows: 5355
- Participants: 5
- Sessions: 15
- Classes: 3
- Features: 36

## Subject-independent predictive results

| model | Macro-F1 mean | Macro-F1 SD | Minimum | Maximum |
| --- | --- | --- | --- | --- |
| Random Forest compact | 0.98652 | 0.02214 | 0.94756 | 1.00000 |
| Decision Tree d6 | 0.98367 | 0.02372 | 0.94268 | 1.00000 |
| MLP compact 32-16 | 0.98089 | 0.02753 | 0.93252 | 0.99907 |
| Logistic Regression | 0.97953 | 0.02757 | 0.93129 | 1.00000 |
| MLP reference 64-32 | 0.97780 | 0.03741 | 0.91141 | 1.00000 |

The confidence intervals in the CSV summary use participant-clustered
bootstrap resampling. With five independent participants, they are descriptive
and must not be interpreted as high-powered population inference.

## Exported model representations

| model | Payload bytes | Activation RAM bytes | Operations | Parity |
| --- | --- | --- | --- | --- |
| Logistic Regression | 444 | 12 | 108 | 1.00000 |
| Decision Tree d6 | 814 | 12 | 6 | 1.00000 |
| Random Forest compact | 11932 | 12 | 90 | 1.00000 |
| MLP compact 32-16 | 7052 | 204 | 1712 | 1.00000 |
| MLP reference 64-32 | 18188 | 396 | 4448 | 1.00000 |

`Payload bytes` represents model arrays exported to C++, not the final compiled
flash occupation. Flash, static RAM, minimum heap, latency and energy must be
measured in the ESP32 benchmarking firmware.

PC prediction times are retained only for reproducibility and must not be
reported as ESP32 inference latency.
